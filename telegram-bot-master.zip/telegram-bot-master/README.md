[/echo](https://github.com/mallusrgreatv2/telegram-bot/blob/master/src/commands/echo.js):

![image](https://user-images.githubusercontent.com/69511006/204588121-55a3e1e2-efa1-4645-bbb4-f3f75aed5928.png)
